function checkPassword(form) { 
	id = form.sid.value; 
	if (id == '') {
		alert ("Please enter ID"); 
	}
	// If same return True. 
	else{ 
		
		return true; 
	} 
}