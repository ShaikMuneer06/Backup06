package com;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/Del")
public class Del extends HttpServlet{
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		String email = (String)session.getAttribute("email");
		int id = Integer.parseInt(request.getParameter("id"));
		String option = request.getParameter("option");
		System.out.println(option);
		String password = request.getParameter("password");
		DeleteSurveyDao dao = new DeleteSurveyDao();
		 if(dao.delete(email, password)){
	    	 System.out.println("inside servlet");
	    	 if(option.equals("question")){
	    	 if(dao.del(id)){
				session.setAttribute("email",email);
				session.setAttribute("password", password);
				response.sendRedirect("DeleteSuccess.html");
				System.out.println("success");
	    	 }
	    	 else{
	  	  	  	   System.out.println("fail");
	  	  	  	response.sendRedirect("DeleteFail.html");
	  	  	     } 
	    	 }
	    	 else if(option.equals("register")){
	    		 if(dao.del1(id)){
	 				session.setAttribute("email",email);
	 				session.setAttribute("password", password);
	 				response.sendRedirect("DeleteSuccess.html");
	 				System.out.println("success");
	 	    	 } 
	    		 else{
	  	  	  	   System.out.println("fail");
	  	  	  	response.sendRedirect("DeleteFail.html");
	  	  	     } 
	    	 }
	     }
	     else{
	  	   System.out.println("fail");
	  	 response.sendRedirect("DeleteError.html");
	     } 
	}

}
