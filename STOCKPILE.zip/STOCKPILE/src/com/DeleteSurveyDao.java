package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

class Delete{
	int id;
	String email;
	String password;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
public class DeleteSurveyDao {
	public boolean delete(String email, String password ){
		try{
			Delete d = new Delete();
			d.setEmail(email);
			d.setPassword(password);
			 Class.forName("oracle.jdbc.driver.OracleDriver");
		     System.out.println("Driver loaded successfully..");
		     Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system" ,"system");
		     System.out.println("Connection established successfully...");
		     String sql = "select * from account where email=? and password=?";
		     System.out.println("st executed");
		     PreparedStatement st = con.prepareStatement(sql);
		     System.out.println("email="+d.getEmail());
		     st.setString(1,d.getEmail());
		     System.out.println("st");
		     System.out.println("password="+d.getPassword());
		     st.setString(2,d.getPassword());
		     System.out.println("st");
		     ResultSet rs = st.executeQuery();
		     if(rs.next()){
		  	   return true;
		     }
			
		}
		catch(Exception e){
			System.out.println(e);
		}
		return false;
	}
public boolean del(int id){
	try{
	Delete d1 = new Delete();
	d1.setId(id);
	 Class.forName("oracle.jdbc.driver.OracleDriver");
     System.out.println("Driver loaded successfully..");
     Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system" ,"system");
     System.out.println("Connection established successfully...");
     String sql1 = "delete from response where id = ?";
  	 PreparedStatement st1 = con.prepareStatement(sql1);
  	 st1.setInt(1,d1.getId());
  	int rs1 = st1.executeUpdate();
  	 String sql2 = "delete from question where id = ?";
  	 PreparedStatement st2 = con.prepareStatement(sql2);
  	 st2.setInt(1,d1.getId());
  	int rs2 = st2.executeUpdate();
  	 String sql3 = "delete from surveyid where id = ?";
  	 PreparedStatement st3 = con.prepareStatement(sql3);
  	 st3.setInt(1,d1.getId());
  	int rs3 = st3.executeUpdate();
  	if(rs3>0){
  		con.commit();
  		return true;
  	}
  	else{
  		return false;
  	}
	}
	catch(Exception e){
		System.out.println(e);
	}
	return false;
	}
public boolean del1(int id){
	try{
	Delete d1 = new Delete();
	d1.setId(id);
	 Class.forName("oracle.jdbc.driver.OracleDriver");
     System.out.println("Driver loaded successfully..");
     Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system" ,"system");
     System.out.println("Connection established successfully...");
     String sql1 = "delete from formb where id = ?";
  	 PreparedStatement st1 = con.prepareStatement(sql1);
  	 st1.setInt(1,d1.getId());
  	int rs1 = st1.executeUpdate();
  	 String sql2 = "delete from registerb where id = ?";
  	 PreparedStatement st2 = con.prepareStatement(sql2);
  	 st2.setInt(1,d1.getId());
  	int rs2 = st2.executeUpdate();
  	String sql4 = "delete from forma where id = ?";
	 PreparedStatement st4 = con.prepareStatement(sql4);
	 st4.setInt(1,d1.getId());
	int rs4 = st4.executeUpdate();
	String sql5 = "delete from registera where id = ?";
	 PreparedStatement st5 = con.prepareStatement(sql5);
	 st5.setInt(1,d1.getId());
	int rs5 = st5.executeUpdate();
  	 String sql3 = "delete from registerid where id = ?";
  	 PreparedStatement st3 = con.prepareStatement(sql3);
  	 st3.setInt(1,d1.getId());
  	int rs3 = st3.executeUpdate();
  	if(rs3>0){
  		con.commit();
  		return true;
  	}
  	else{
  		return false;
  	}
	}
	catch(Exception e){
		System.out.println(e);
	}
	return false;
	}
}


	