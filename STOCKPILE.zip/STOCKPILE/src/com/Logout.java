package com;

import java.io.IOException;  
import java.io.PrintWriter;  
  
import javax.servlet.ServletException;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
import javax.servlet.http.HttpSession;
@WebServlet("/Logout")
public class Logout extends HttpServlet {  
        protected void doGet(HttpServletRequest request, HttpServletResponse response)  
                                throws ServletException, IOException {  
        	HttpSession session = request.getSession();

            // Invalidate the session and removes any attribute related to it
            session.invalidate();

            
            // session will be null.
            session = request.getSession(false);
            System.out.println(session);
            response.sendRedirect("login.html");
            System.out.println("s");
    }  
}  
