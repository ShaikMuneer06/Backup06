package crud;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Insert")
public class Insert extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		int score = Integer.parseInt(request.getParameter("score"));
		Pojo p = new Pojo();
		p.setId(id);
		p.setName(name);
		p.setScore(score);
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		    System.out.println("Driver loaded successfully..");
		    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system" ,"system");
		    System.out.println("Connection established successfully...");
		    String sql = "insert into score values(?,?,?)";
		    PreparedStatement st = con.prepareStatement(sql);
		    st.setInt(1,p.getId());
		    st.setString(2, p.getName());
		    st.setInt(3,p.getScore());
		    int rs = st.executeUpdate();
		    System.out.println(rs);
		    if(rs>0){
		 	   con.commit();
		 	   System.out.println("Inserted");
		}
		    else{
		    	System.out.println("Failed");
		    }
		}
		catch(Exception e){
			System.out.println(e);
		}
	}

}
