package crud;

public @interface WebServlet {

	String value();

}
