package crud;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/View")
public class View extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		Pojo p = new Pojo();
		p.setId(id);
		PrintWriter out = response.getWriter();  
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		    System.out.println("Driver loaded successfully..");
		    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system" ,"system");
		    System.out.println("Connection established successfully...");
		    String sql = "select * from score where id=?";
		    PreparedStatement st = con.prepareStatement(sql);
		    st.setInt(1,p.getId());
		    ResultSet rs=st.executeQuery();  
		    System.out.println(rs);  
		    while(rs.next())  
		    {  
		    	out.print("ID:"+rs.getInt(1)+"\nNAME:"+rs.getString(2)+"\nSCORE:"+rs.getInt(3));                   
		    }  
		}
		catch(Exception e){
			System.out.println(e);
		}
	}

}
